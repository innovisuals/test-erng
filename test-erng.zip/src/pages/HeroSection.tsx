
import React, { useEffect, useState } from 'react'

export default function HeroSection() {
  const [showScrollLogo, setShowScrollLogo] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollLogo(window.scrollY > 100)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <section className="relative h-screen bg-coolteal text-ivory flex items-center justify-center overflow-hidden transition-all">
      {/* INNOVISUAL MP4 logo placeholder */}
      <div
        className={`transition-all duration-1000 ease-out ${
          showScrollLogo
            ? 'opacity-0 scale-95 pointer-events-none'
            : 'opacity-100 scale-100'
        }`}
      >
        <img
          src="/Logo-fffcef-1080.png"
          alt="INNOVISUAL"
          className="h-40 w-auto mx-auto"
        />
      </div>

      {/* Scroll-logo versie */}
      {showScrollLogo && (
        <img
          src="/Logo-5c899d-320.png"
          alt="INNOVISUAL"
          className="fixed top-6 left-6 h-10 w-auto transition-all duration-700 ease-in-out z-50"
        />
      )}

      {/* Scroll indicator */}
      {!showScrollLogo && (
        <div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-ivory text-4xl animate-bounce cursor-pointer"
          onClick={() =>
            document.getElementById('vctb')?.scrollIntoView({ behavior: 'smooth' })
          }
        >
          ↓
        </div>
      )}
    </section>
  )
}
