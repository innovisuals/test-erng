
import React from 'react'
import HeroSection from './HeroSection'

export default function App() {
  return (
    <>
      <HeroSection />
      <section id="vctb" className="min-h-screen bg-ivory text-coolteal flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-4xl font-bold">Van Creatie tot Beleving</h2>
          <p className="mt-4 max-w-xl mx-auto">
            Hier komt straks de INNOVISUAL uitleg over het proces en het AR-systeem.
          </p>
        </div>
      </section>
    </>
  )
}
